// Edge config for Vercel edge functions
module.exports = {
  runtime: 'edge'
};