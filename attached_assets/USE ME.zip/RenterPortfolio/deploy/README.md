# Minimal Warplet Traders Deployment

This is a minimal deployment package created for the Vercel Hobby plan.
It contains only the essential files needed to run the app while staying
under the 12 serverless function limit.

## Deployment

To deploy this package:

```bash
cd deploy
vercel
```
